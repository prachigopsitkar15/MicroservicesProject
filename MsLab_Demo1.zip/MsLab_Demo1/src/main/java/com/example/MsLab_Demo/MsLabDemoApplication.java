package com.example.MsLab_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsLabDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsLabDemoApplication.class, args);
	}

}
