package com.example.MsLab_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsLabDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
